# image_processing

Description.
The package image_processing is used to:
    Processing:
        - Histogram matching
        - Structural similar
        - Resize image
    Utils:
        - Read image
        - Save image
        - Plot image
        - Plot result
        - Plot Histogram

## Installation

Use the package manager [pip](http://pip.pypa.io/en/stable/) to install package_name

'''bash
pip install image_processing-mauriciogianezini
'''

## Author
Mauricio Gianezini

## License
[MIT](http://schoosealicense.com/licenses/mit)